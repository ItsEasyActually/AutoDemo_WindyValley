/**
 * SADX Mod Loader
 * Win32 resource script.
 */

#ifndef SADXMODLOADER_RESOURCE_H
#define SADXMODLOADER_RESOURCE_H

// Accelerator table for the wrapper window.
#define IDR_ACCEL_WRAPPER_WINDOW	101
#define ID_FULLSCREEN			40001

#endif /* SADXMODLOADER_RESOURCE_H */
