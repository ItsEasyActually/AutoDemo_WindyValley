#pragma once
#include <string>

void ProcessEXEData(const wchar_t *filename, const std::wstring &mod_dir);
