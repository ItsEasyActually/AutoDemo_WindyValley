# Sonic Adventure DX PC Mod Loader
Version 3.7

## System Requirements

To use SADX Mod Loader, you must have:
* Sonic Adventure DX PC, 2004 version (US release)
* Windows XP or later

## License

DISCLAIMER:
Any and all content presented in this repository is presented for
informational and educational purposes only. Commercial usage is
expressly prohibited. Sonic Retro claims no ownership of any code
in these repositories. You assume any and all responsibility for
using this content responsibly. Sonic Retro claims no responsibility
or warranty.


## Trademarks

Sega, Sonic, Sonic the Hedgehog, and Sonic Adventure DX are either
trademarks or registered trademarks of SEGA of America, Inc.
